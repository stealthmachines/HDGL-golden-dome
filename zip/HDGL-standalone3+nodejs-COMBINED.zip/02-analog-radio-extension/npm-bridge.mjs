/**
 * npm-bridge.mjs
 * ══════════════════════════════════════════════════════════════════════════
 * Host-side consumer of the Router64 phi-bridge mailbox.
 * Run this on first OS boot after the firmware's `npm <package>` command.
 *
 * Mailbox layout written by sh_cmd_npm in hdgl_router64.asm:
 *   0x50000 +  0  dword  0x48444C47  HDGL magic
 *   0x50000 +  4  dword  0x00000001  version
 *   0x50000 +  8  ...    (standard phi-bridge fields)
 *   0x50000 +100  dword  0x6E706D01  NPM_INSTALL flag
 *   0x50100 +  0  asciiz package name (max 128 bytes)
 *
 * On real hardware:  node npm-bridge.mjs
 * In QEMU/dev:       node npm-bridge.mjs --sim <package>
 * ══════════════════════════════════════════════════════════════════════════
 */

import { execSync }  from 'child_process';
import { readFileSync, openSync, readSync, closeSync } from 'fs';

const HDGL_MAGIC      = 0x48444C47;
const NPM_INSTALL_FLAG = 0x6E706D01;
const MAILBOX_BASE    = 0x50000;
const FLAGS_OFFSET    = 100;           // byte 100 from mailbox base
const PKG_NAME_BASE   = 0x50100;       // package name written here by firmware

// ── helpers ──────────────────────────────────────────────────────────────────

function readU32LE(buf, off) {
  return buf[off] | (buf[off+1] << 8) | (buf[off+2] << 16) | (buf[off+3] << 24);
}

function readAsciiZ(buf) {
  const end = buf.indexOf(0);
  return buf.slice(0, end < 0 ? buf.length : end).toString('ascii');
}

// ── mailbox readers ───────────────────────────────────────────────────────────

function readFromDevMem() {
  const fd = openSync('/dev/mem', 'r');
  const mailbox = Buffer.alloc(104 + 1);
  readSync(fd, mailbox, 0, 104, MAILBOX_BASE);
  const pkgBuf = Buffer.alloc(128);
  readSync(fd, pkgBuf, 0, 128, PKG_NAME_BASE);
  closeSync(fd);
  return { mailbox, pkgBuf };
}

// ── sim: write mailbox into a local Buffer as firmware would have done ────────

function simMailbox(pkgName) {
  const mailbox = Buffer.alloc(104);
  // +0   HDGL magic
  mailbox.writeUInt32LE(HDGL_MAGIC, 0);
  // +4   version
  mailbox.writeUInt32LE(1, 4);
  // +100 NPM_INSTALL flag
  mailbox.writeUInt32LE(NPM_INSTALL_FLAG, FLAGS_OFFSET);
  const pkgBuf = Buffer.alloc(128);
  Buffer.from(pkgName, 'ascii').copy(pkgBuf);
  return { mailbox, pkgBuf };
}

// ── main ──────────────────────────────────────────────────────────────────────

const args = process.argv.slice(2);
let mailbox, pkgBuf;

if (args[0] === '--sim' && args[1]) {
  console.log(`[npm-bridge] simulation mode — package: ${args[1]}`);
  ({ mailbox, pkgBuf } = simMailbox(args[1]));
} else {
  console.log('[npm-bridge] reading phi-bridge mailbox from /dev/mem …');
  try {
    ({ mailbox, pkgBuf } = readFromDevMem());
  } catch (e) {
    console.error('[npm-bridge] /dev/mem unavailable:', e.message);
    console.error('             run with --sim <package> to test without hardware');
    process.exit(1);
  }
}

// ── verify mailbox ────────────────────────────────────────────────────────────

const magic = readU32LE(mailbox, 0);
const flag  = readU32LE(mailbox, FLAGS_OFFSET);

console.log(`[npm-bridge] magic=0x${magic.toString(16).toUpperCase().padStart(8,'0')} ` +
            `flags=0x${(flag >>> 0).toString(16).toUpperCase().padStart(8,'0')}`);

if (magic !== HDGL_MAGIC) {
  console.error('[npm-bridge] bad magic — no HDGL mailbox at 0x50000');
  process.exit(1);
}
if ((flag >>> 0) !== (NPM_INSTALL_FLAG >>> 0)) {
  console.error(`[npm-bridge] flags != NPM_INSTALL (0x6E706D01) — nothing to do`);
  process.exit(0);
}

// ── extract and validate package name ────────────────────────────────────────

const pkgName = readAsciiZ(pkgBuf).trim();
if (!pkgName || !/^[@\w][\w./-]*$/.test(pkgName)) {
  console.error(`[npm-bridge] invalid package name in mailbox: "${pkgName}"`);
  process.exit(1);
}

console.log(`[npm-bridge] NPM_INSTALL flag confirmed — package: ${pkgName}`);
console.log(`[npm-bridge] executing: npm install ${pkgName}`);

// ── execute ───────────────────────────────────────────────────────────────────

try {
  const out = execSync(`npm install ${pkgName}`, {
    cwd: process.cwd(),
    stdio: 'inherit',
  });
} catch (e) {
  console.error('[npm-bridge] npm install failed:', e.message);
  process.exit(1);
}

console.log(`[npm-bridge] installed ${pkgName} — phi-bridge handoff complete`);
