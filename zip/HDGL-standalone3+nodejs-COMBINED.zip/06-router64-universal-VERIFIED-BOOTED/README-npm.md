# HDGL Router64 — npm command + phi-bridge install

## What changed

Three files were modified or created to add Node.js package installation
to the Router64 bare-metal shell.

| File | Change | Lines |
|------|--------|-------|
| `src/hdgl_router64.asm` | +102 lines: dispatch entry + `sh_cmd_npm` handler | 3926 |
| `npm-bridge.mjs` | New — host-side phi-bridge consumer | 125 |
| `analog-container.mjs` | Replaced fabricated stub with real 598-line file from `stealthmachines/EZ-by-zCHG-W-LM-Studio-and-3-LLM-s-in-Council` | 598 |

### Build artifacts (unchanged filenames, new checksums)

```
bin/hdgl_mbr.bin        512 B    feabd25073e2ea9d68d1535b5c7f0ce1
bin/hdgl_router64.bin   32 KB    ce60cbade1fc9b8409bd0a4a338dda32
bin/hdgl_router64.img   1.0 MB   b7209cc11c99b97501d81838166e0209
uefi/BOOTX64.EFI        704 B    0225003e348e079dd6f34c316da32e30
```

---

## The npm command

`npm` is command 30 in the Router64 shell (was 23 before the security layer,
now 29 after `advance`, `attest`, `cap`, `seal`, `unseal`, `nic`, `uart`,
`boot`).

**Syntax**

```
Router64> npm <package>
```

**What it does**

1. Copies `<package>` (max 127 bytes, ascii-z) to physical address `0x50100`
   — directly past the 104-byte phi-bridge mailbox.
2. Writes the standard phi-bridge mailbox at `0x50000`:
   - `+0`   `0x48444C47`  HDGL magic
   - `+4`   `0x00000001`  version
   - `+8..99`             genome_fp, NIC table ptr, UART table ptr,
                          phi-lattice tick, Kuramoto aphase (same as `boot`)
   - `+96`  `0x00000080`  boot drive (default)
   - `+100` `0x6E706D01`  **NPM_INSTALL flag** — distinguishes this from a
                          plain `boot`
3. Copies `.phib_trampoline` to `0x4000`, issues `lgdt [gdt32_ptr]` and
   far-retf into 32-bit mode, chainloads drive `0x80`.
4. The host OS boots. `npm-bridge.mjs` runs (see §Host setup below),
   reads `/dev/mem` at `0x50000` and `0x50100`, verifies magic + flag,
   and executes `npm install <package>`.

**Example session**

```
Router64> npm express
[npm] install: express
[npm] phi-bridge armed (flag=0x6E706D01) -> chainloading OS

... host OS boots ...

[npm-bridge] magic=0x48444C47 flags=0x6E706D01
[npm-bridge] NPM_INSTALL flag confirmed — package: express
[npm-bridge] executing: npm install express
added 64 packages in 2s
[npm-bridge] installed express — phi-bridge handoff complete
```

**No-arg error**

```
Router64> npm
[npm] usage: npm <package>
```

---

## QEMU

### Prerequisites

```sh
nasm >= 2.14
gcc  >= 9
node >= 18
qemu-system-x86_64
```

### Build

```sh
cd 06-router64-universal-VERIFIED-BOOTED
bash build.sh
```

Expected output ends with `8 pass  0 fail`, Kuramoto LOCK in 21 steps,
Dn aggregate `0x80C0C0E8`.

### Boot

```sh
qemu-system-x86_64 \
    -drive file=bin/hdgl_router64.img,format=raw,if=ide \
    -boot order=c \
    -m 64M \
    -serial stdio \
    -no-reboot \
    -display none
```

Serial output appears on stdout. You will see:

```
HDGL/64 Router> phi-lattice live (64-bit). help<enter>
Router64>
```

Type `help` for the full command list. Type `npm <package>` to arm the
phi-bridge and chainload.

### QEMU with host OS for full npm round-trip

Boot QEMU with a Linux image as the secondary drive so chainload lands in
a real OS that can run `npm-bridge.mjs`:

```sh
qemu-system-x86_64 \
    -drive file=bin/hdgl_router64.img,format=raw,if=ide,index=0 \
    -drive file=/path/to/linux.img,format=qcow2,if=ide,index=1 \
    -boot order=c \
    -m 256M \
    -serial stdio \
    -no-reboot \
    -display none
```

Then at `Router64>`:

```
npm lodash
```

Chainload fires. Linux boots. `npm-bridge.mjs` runs (see §Host setup),
reads `/dev/mem`, installs lodash.

---

## Bare metal

### Hardware target

Gigabyte H81-BTC-Pro  
Intel i217-V NIC — PCI ID `8086:153A`  
Legacy BIOS (UEFI stub included but prefers legacy)

### Flash

```sh
# Find your target device first — wrong device = data loss
lsblk

# Flash (replace /dev/sdX)
sudo dd if=bin/hdgl_router64.img of=/dev/sdX bs=512 oflag=sync
sync
```

`hdgl_router64.img` is a 1 MB raw image: MBR at sector 0, 64-sector
Router64 runtime at sectors 1–64. Flash to USB, CF, mSATA, or SSD.

### UEFI boards

Copy `uefi/BOOTX64.EFI` to `/EFI/BOOT/BOOTX64.EFI` on a FAT32
ESP partition. The stub detects legacy-BIOS capability and prefers it;
on pure-UEFI boards it enters a compatibility shim.

### Serial console

Connect a 3.3 V UART adapter to COM1 header on the H81-BTC-Pro.
9600 8N1. On the host machine:

```sh
minicom -D /dev/ttyUSB0 -b 9600
# or
screen /dev/ttyUSB0 9600
```

The prompt `Router64>` appears a few hundred milliseconds after power-on.

---

## Host setup — npm-bridge.mjs

`npm-bridge.mjs` must run once on every boot of the host OS that follows
a Router64 `npm` command. On Linux this means `/dev/mem` access (requires
`CONFIG_DEVMEM=y` and either root or `CAP_SYS_RAWIO`).

### Systemd oneshot (recommended)

```ini
# /etc/systemd/system/hdgl-npm-bridge.service
[Unit]
Description=HDGL phi-bridge npm consumer
After=local-fs.target network.target
ConditionPathExists=/dev/mem

[Service]
Type=oneshot
ExecStart=/usr/bin/node /opt/hdgl/npm-bridge.mjs
WorkingDirectory=/opt/hdgl
RemainAfterExit=no

[Install]
WantedBy=multi-user.target
```

```sh
sudo systemctl enable hdgl-npm-bridge
```

### rc.local (simpler)

```sh
echo "node /opt/hdgl/npm-bridge.mjs >> /var/log/hdgl-npm-bridge.log 2>&1" \
    >> /etc/rc.local
chmod +x /etc/rc.local
```

### Test without hardware

```sh
node npm-bridge.mjs --sim <package>
```

Simulates the firmware mailbox entirely in memory, no `/dev/mem` access.

---

## Mailbox memory map summary

| Address | Size | Written by | Content |
|---------|------|-----------|---------|
| `0x50000` | 4 B | `npm` cmd | `0x48444C47` (HDGL magic) |
| `0x50004` | 4 B | `npm` cmd | `0x00000001` (version) |
| `0x50008` | 88 B | `npm` cmd | phi-bridge fields (genome_fp, NIC/UART tables, tick, aphase) |
| `0x50060` | 4 B | `npm` cmd | `0x00000080` (boot drive) |
| `0x50064` | 4 B | `npm` cmd | `0x6E706D01` (NPM_INSTALL flag) |
| `0x50100` | ≤128 B | `npm` cmd | Package name, ascii-z |

The `boot` command writes the same mailbox but sets flags = `0x00000000`.
`npm-bridge.mjs` distinguishes them by the flags field.

---

## Fabric self-test

```sh
# Fabric agent (analog-container + phi-lattice tests)
cd 02-analog-radio-extension
node fabric_node_agent.mjs --test
# → 10 passed, 0 failed

# npm-bridge simulation
cd ../fabric-node
node npm-bridge.mjs --sim is-odd
# → installs is-odd via npm
```
