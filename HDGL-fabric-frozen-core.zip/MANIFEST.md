# HDGL Fabric — Frozen Core

23 files, 11,005 lines, ~470 KB. Verified byte-identical (md5) across
every tag from v0.1 (June 6) through v0.4 (current head of the Analog
Fabric line) — meaning none of this code has changed since the earliest
upload you gave me. Everything that *did* move between v0.1 and v0.4 was
packaging, docs, or the one real addition noted at the bottom.

Files here are taken from the v0.4 copy (irrelevant which tag they're
pulled from, since all five are identical).

## Native glyph layer (NASM-only emit path — no C compiler on the boot path)

| File | Lines | Role |
|---|---:|---|
| `SUITE.hdgl` | 451 | Suite manifest: file tree, six integration seams, build procedure, two-node test guide. Self-describing — the running fabric can load and parse this file. Frozen since **v0.2** (didn't exist at v0.1). |
| `hdgl_fabric.hdgl` | 881 | Root glyph. Boot, kernel, genome, carrier, transport, store, shell, loader all derive from this. |
| `hdgl_genome.hdgl` | 414 | Omega graph → base-4 codec → genome statistics → all derived parameters. The hardware IS the genome; no FASTA. |
| `hdgl_genome_shell.hdgl` | 548 | Five shell commands: `genome`, `fabric`, `ftick`, `fgossip`, `fauth`. |
| `hdgl_peer_discovery.hdgl` | 363 | Three-phase peer discovery: phi-seed multicast (239.x.x.x derived from genome_fp), ARP probe, sector-68 static list. |
| `hdgl_complete.hdgl` | 1277 | NIC timing integration, bootstrap globals, metal store init, disk image extension, boot sequence, five fabric shell commands (`nic2`, `store`, `peers`, `send`, `load`), smoke test script. |

## Assembly (bare-metal NIC driver)

| File | Lines | Role |
|---|---:|---|
| `hdgl_nic.asm` | 649 | Intel e1000 + Realtek RTL8111/8168 driver. PCI enumeration, ring buffer init, TX/RX, MMIO registers. This is the file that 0.3c's `HDGL_CONSOLIDATED.hdgl` later documents H81-BTC-Pro/i217-V BAR64+RCTL patches against — those patches are described in that spec but, per the 0.3e bug-fix notes, were never actually carried into the boot-tested Router64 assembly. This file itself is untouched. |

## C layer (POSIX transport daemon + bare-metal store — disposable once hardware confirms the glyph emit)

| File | Lines | Role |
|---|---:|---|
| `hdgl_genome_fabric.c` / `.h` | 564 / 166 | Genome codec: base-4 encode, k-mer stats, Shannon entropy, transition matrix, Kuramoto phases, palette derivation, gossip EMA update. |
| `zchg_carrier.h` | 319 | Three steganographic channels: CH-0 frame.reserved, CH-1 gossip strand_weights LSB-2, CH-2 `/serve/zc/` phi-path. `phi_fold32` primitive lives here. |
| `zchg_core_patch.h` | 38 | Extends `zchg_gossip_msg_t` with `dn_aggregate` + `genome_fingerprint` (wire-backward-compatible). |
| `zchg_frame_patched.c` | 182 | CH-0 carrier wired into frame send/receive path. |
| `zchg_gossip_patched.c` | 198 | CH-1 carrier wired into gossip message creation/reception. |
| `zchg_http_patched.c` | 1433 | CH-2 `/serve/zc/` handler + full HTTP/1.1 transport with phi-fold routing. |
| `zchg_lattice_patch.c` | 115 | `zchg_lattice_apply_gossip` extended with genome EMA convergence call. |
| `zchg_store_metal.c` | 541 | Bare-metal store — ATA PIO I/O, phi-lattice arena allocator, strand-native sector layout. No libc, no POSIX. |
| `hdgl_fabric_loader.c` / `.h` | 339 / 44 | Loader — the FNV-phi spiral primitives later ported verbatim into `fabric_node_agent.mjs`. |
| `Makefile` | 50 | Standalone C test build (`make test`, `make verify`). Links only `-lm`. |

## JavaScript / MCP layer

| File | Lines | Role |
|---|---:|---|
| `fabric_node_agent.mjs` | 1462 | Multi-node fabric integration for the AI bot. `discoverFabricNodes()`, `routePassToNode()`, `fabricErlAppend()`, `attachFabricHandlers()` (mounts `/health`, `/gossip`, `/fabric/store`, `/fabric/query`, `/fabric/peers`, `/fabric/status`). Zero third-party dependencies. Frozen since **v0.2** (didn't exist at v0.1, where it wasn't yet written — the v0.1 `old files` archive's `EZ-by-zCHG...` zip is its conceptual predecessor). |

## Test harness (also frozen — confirmed byte-identical to v0.1 despite being packaged in/out of intermediate tags)

| File | Lines | Role |
|---|---:|---|
| `hdgl_fabric_test.c` | 302 | Test harness for `hdgl_fabric_loader.c`. |
| `hdgl_genome_test.c` | 293 | Test harness for `hdgl_genome_fabric.c`. |
| `zchg_carrier_test.c` | 376 | Test harness for the three steganographic carrier channels in `zchg_carrier.h`. |

These exist at v0.1 (zipped inside `fabric1.zip`/`fabric2.zip`/`fabric3.zip`), are absent from v0.2 and v0.3's top-level file listing, and reappear at v0.3b — but the v0.3b copies are byte-identical to the v0.1 copies. They were dropped from packaging twice, never rewritten.

## The one thing that is NOT in this set

`hdgl_analog_fabric_radio.hdgl` (944 lines) is the sole code-level addition
across the entire v0.1→v0.4 span. It first appears at v0.4 and is what
HDGL-golden-dome continues from. Everything above predates it and has not
changed since it was added.

## What moved instead of the code

- v0.1 → v0.2: `SUITE.hdgl` and `fabric_node_agent.mjs` introduced (new
  code, not a revision of anything). Three test files
  (`hdgl_fabric_test.c`, `hdgl_genome_test.c`, `zchg_carrier_test.c`)
  present at v0.1 (zipped inside `fabric1–3.zip`) disappear at v0.2.
- v0.2 → v0.3: documentation only (README expanded 10→95 lines explaining
  `fabric_node_agent.mjs` design rationale) + one architecture diagram
  added. No code changed.
- v0.3 → v0.3b: the three test files reappear, and are byte-identical to
  the v0.1 copies — so they were never rewritten, just dropped from the
  v0.2/v0.3 packaging and put back at v0.3b.
- v0.3b → v0.4: test files removed again; `hdgl_analog_fabric_radio.hdgl`
  added.
